package Ejercicio1;

public class Main {

	public static void main(String[] args) {
		
		int elec = 0;
		
		System.out.println("Escribe tu Usuario: ");
		
		System.out.println("Escribe la Contraseña: ");
		
		switch(elec) {
		case 1:
			
			break;
		case 2:
			
			break;
		case 3:
			
			break;
		case 4:
			
			break;
		}
		
	}

}
