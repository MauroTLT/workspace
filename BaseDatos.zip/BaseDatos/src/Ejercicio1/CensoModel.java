package Ejercicio1;

import java.util.ArrayList;

public class CensoModel {

	private ArrayList<Persona> personas;
	
	public CensoModel() {
		this.personas = new ArrayList<Persona>();
	}

	public ArrayList<Persona> getPersonas() {
		return personas;
	}

	public void setPersonas(ArrayList<Persona> personas) {
		this.personas = personas;
	}

}
