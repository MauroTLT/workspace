package Ejercicio1;

public class JDBCCensoDAO implements CensoDAO {

	@Override
	public void insertPersona() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void removePersona(int dni) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Persona consulta(int dni) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void modify(int dni, int tupla, String cambio) {
		// TODO Auto-generated method stub
		
	}


}
