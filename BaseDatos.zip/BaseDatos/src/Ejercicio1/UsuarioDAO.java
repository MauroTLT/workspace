package Ejercicio1;

public interface UsuarioDAO {
	
	public Persona consulta(int dni);
	
}
