package Ejercicio1;

public class JDBCUsuarioDAO implements UsuarioDAO{

	@Override
	public Persona consulta(int dni) {
		// TODO Auto-generated method stub
		return null;
	}

}
