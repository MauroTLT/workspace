package unidad8.practica4;

public class Clientes {
	private String nombre;

	public Clientes(String nombre) {
		this.nombre = nombre;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	
}
