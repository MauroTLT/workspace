package Ejemplo1;

public class ClaseZ extends ClaseX {
	
	public void met1() {
		System.out.println("Codi Z");
	}
	public void met2() {
		System.out.println("Metodo 2");
	}
}
