package Ejemplo1;

public abstract class ClaseX {
	
	public void met1() {
		System.out.println("Codi X");
	}
	public abstract void met2();
}
