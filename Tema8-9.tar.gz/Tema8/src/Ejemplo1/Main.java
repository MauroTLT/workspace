package Ejemplo1;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ClaseX ox = new ClaseZ();
		ClaseX oz = new ClaseZ();
		
		ox.met1();
		oz.met1();
		ox.met2();
		oz.met2();
	}

}
