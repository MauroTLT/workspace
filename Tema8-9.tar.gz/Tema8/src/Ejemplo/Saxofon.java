package Ejemplo;

public class Saxofon extends Instrumento {

	public void tocar() {
		System.out.println("Tocando Saxofon");

	}

}
