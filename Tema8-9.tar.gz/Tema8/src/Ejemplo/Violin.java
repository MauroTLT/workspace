package Ejemplo;

public class Violin extends Instrumento {
	
	public void tocar() {
		System.out.println("Tocando Violin");

	}

}
