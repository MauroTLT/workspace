package Ejemplo;

public class Guitarra extends Instrumento {

	public void tocar() {
		System.out.println("Tocando Guitarra");
	}
	
}
