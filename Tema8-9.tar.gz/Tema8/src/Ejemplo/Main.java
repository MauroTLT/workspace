package Ejemplo;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Instrumento instrumento = new Instrumento();
		Instrumento g1 = new Violin();
		Saxofon s1 = new Saxofon();
		Violin v1 = new Violin();
		
		g1.tocar();
		v1.tocar();
		s1.tocar();
		
	}

}
