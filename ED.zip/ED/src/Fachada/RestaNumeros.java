package Fachada;

public class RestaNumeros {
	public int resta(int pA, int pB) {
		return pA - pB;
	}
}
