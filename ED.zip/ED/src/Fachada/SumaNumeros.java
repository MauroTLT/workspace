package Fachada;

public class SumaNumeros {
	public int suma(int pA, int pB) {
		return pA + pB;
	}
}
