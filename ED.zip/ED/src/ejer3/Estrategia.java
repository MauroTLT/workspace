package ejer3;

public interface Estrategia {
	public void saludar();
}
