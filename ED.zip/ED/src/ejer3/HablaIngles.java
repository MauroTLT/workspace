package ejer3;

public class HablaIngles implements Estrategia{

	@Override
	public void saludar() {
		System.out.println("Hello Jose");
	}

}
