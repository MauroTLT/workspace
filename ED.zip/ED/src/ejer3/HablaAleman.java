package ejer3;

public class HablaAleman implements Estrategia{

	@Override
	public void saludar() {
		System.out.println("Hallo Jose");
	}

}
