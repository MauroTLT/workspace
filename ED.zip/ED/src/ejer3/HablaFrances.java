package ejer3;

public class HablaFrances implements Estrategia{

	@Override
	public void saludar() {
		System.out.println("Bonjour Jose");
	}

}
