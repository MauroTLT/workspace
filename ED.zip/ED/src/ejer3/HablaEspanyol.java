package ejer3;

public class HablaEspanyol implements Estrategia{

	@Override
	public void saludar() {
		System.out.println("Hola Jose");
		
	}

}
