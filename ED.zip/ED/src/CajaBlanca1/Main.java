package CajaBlanca1;

public class Main {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CalculadoraPolacaInversa calculadora = new CalculadoraPolacaInversa();
		System.out.println(calculadora.calcular(2.0, 2.0, "%"));
		
	}
}