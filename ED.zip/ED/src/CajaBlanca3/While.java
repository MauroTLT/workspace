package CajaBlanca3;

public class While {
	public int bucle(int num) {
		// Definimos el bucle, incluye el 100
		while (num < 100) {
			System.out.println(num);
			// Incrementamos num
			num++;
		}
		return num;
	}
}
