package CajaBlanca3;

public class MuestraNumWhileApp {
	public static void main(String[] args) {
		While ejemplo = new While();
		int num = 1;
		System.out.println(ejemplo.bucle(num));
	}
}