package Responsabilidad;

public class Peticion {
	private int value;

	public Peticion(int value) {
		this.value = value;
	}

	public int getValue() {
		return value;
	}
}